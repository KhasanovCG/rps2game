package classobject.rps25game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// GUI class for the Rock Paper Scissors 25 game
public class RPS25GUI extends JFrame {
    private Game game;
    private JComboBox<String> player1ComboBox;
    private JComboBox<String> player2ComboBox;
    private JLabel resultLabel;
    private JLabel scoreLabel;
    private int player1Score;
    private int player2Score;
    private String player1Choice;
    private JButton playButton;
    private JButton newRoundButton;

    public RPS25GUI() {
        game = new Game();

        setTitle("Rock Paper Scissors 25");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        player1ComboBox = new JComboBox<>(game.getSymbols());
        player2ComboBox = new JComboBox<>(game.getSymbols());
        playButton = new JButton("Play");
        newRoundButton = new JButton("Start New Round");
        resultLabel = new JLabel("Player 1, make your choice and press Play!", SwingConstants.CENTER);
        scoreLabel = new JLabel("Player 1: 0, Player 2: 0", SwingConstants.CENTER);

        JPanel panel = new JPanel(new GridLayout(5, 1));
        JPanel player1Panel = new JPanel();
        player1Panel.add(new JLabel("Player 1:"));
        player1Panel.add(player1ComboBox);

        JPanel player2Panel = new JPanel();
        player2Panel.add(new JLabel("Player 2:"));
        player2Panel.add(player2ComboBox);
        player2Panel.setVisible(false);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(playButton);
        buttonPanel.add(newRoundButton);
        newRoundButton.setVisible(false);

        panel.add(resultLabel);
        panel.add(player1Panel);
        panel.add(player2Panel);
        panel.add(buttonPanel);
        panel.add(scoreLabel);

        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (player1Choice == null) {
                    player1Choice = (String) player1ComboBox.getSelectedItem();
                    resultLabel.setText("Player 1 has made a choice. Player 2, make your choice and press Play!");
                    player1Panel.setVisible(false);
                    player2Panel.setVisible(true);
                } else {
                    String player2Choice = (String) player2ComboBox.getSelectedItem();
                    String result = game.determineWinner(player1Choice, player2Choice);

                    // Check the result and update the score accordingly
                    if (result.contains(player1Choice)) {
                        player1Score++;
                        resultLabel.setText(player1Choice + " wins! Player 1 scores a point.");
                    } else if (result.contains(player2Choice)) {
                        player2Score++;
                        resultLabel.setText(player2Choice + " wins! Player 2 scores a point.");
                    } else {
                        resultLabel.setText(result); // "It's a tie!"
                    }

                    // Update the score label
                    scoreLabel.setText("Player 1: " + player1Score + ", Player 2: " + player2Score);

                    newRoundButton.setVisible(true);
                    playButton.setEnabled(false);
                }
                panel.revalidate();
                panel.repaint();
            }
        });

        newRoundButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resultLabel.setText("Player 1, make your choice and press Play!");
                player1Choice = null;  // reset player1Choice for the next round

                player1Panel.setVisible(true);
                player2Panel.setVisible(false);
                playButton.setEnabled(true);
                newRoundButton.setVisible(false);

                panel.revalidate();
                panel.repaint();
            }
        });

        add(panel);
    }
}
