package classobject.rps25game;
import classobject.rps25game.Game;
import javax.swing.SwingUtilities;

// Main class to launch the Rock Paper Scissors 25 game
public class RPS25Game {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RPS25GUI().setVisible(true);
            }
        });
    }
}