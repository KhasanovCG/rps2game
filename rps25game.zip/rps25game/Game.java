package classobject.rps25game;

import java.util.HashMap;
import java.util.Map;

// Manages the game logic and symbols
public class Game {
    private Map<String, Symbol> symbols;

    public Game() {
        symbols = new HashMap<>();
        initializeSymbols();
    }

    // Returns the list of all symbols
    public String[] getSymbols() {
        return symbols.keySet().toArray(new String[0]);
    }

    // Initialize all symbols and their defeat relationships
    private void initializeSymbols() {
        addSymbolWithDefeats("GUN", "ROCK", "SUN", "FIRE", "SCISSORS", "AXE", "SNAKE", "MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH", "WOLF");
        addSymbolWithDefeats("DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK", "SUN", "FIRE", "SCISSORS", "AXE", "SNAKE", "MONKEY");
        addSymbolWithDefeats("MOON", "AIR", "BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK", "SUN");
        addSymbolWithDefeats("TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON", "AIR", "BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING");
        addSymbolWithDefeats("AXE", "SNAKE", "MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON", "AIR", "BOWL");
        addSymbolWithDefeats("DYNAMITE", "GUN", "ROCK", "SUN", "FIRE", "SCISSORS", "AXE", "SNAKE", "MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH");
        addSymbolWithDefeats("ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK", "SUN", "FIRE", "SCISSORS", "AXE", "SNAKE");
        addSymbolWithDefeats("PAPER", "MOON", "AIR", "BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK");
        addSymbolWithDefeats("MAN", "TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON", "AIR", "BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL");
        addSymbolWithDefeats("SCISSORS", "AXE", "SNAKE", "MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON", "AIR");
        addSymbolWithDefeats("NUKE", "DYNAMITE", "GUN", "ROCK", "SUN", "FIRE", "SCISSORS", "SNAKE", "AXE", "MONKEY", "WOMAN", "MAN", "TREE");
        addSymbolWithDefeats("WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK", "SUN", "FIRE", "SCISSORS", "AXE");
        addSymbolWithDefeats("SPONGE", "PAPER", "MOON", "AIR", "BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN");
        addSymbolWithDefeats("WOMAN", "MAN", "TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON", "AIR", "BOWL", "WATER", "ALIEN", "DRAGON");
        addSymbolWithDefeats("LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK", "SUN", "FIRE", "SCISSORS", "AXE", "SNAKE", "MONKEY", "WOMAN", "MAN");
        addSymbolWithDefeats("BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK", "SUN", "FIRE", "SCISSORS");
        addSymbolWithDefeats("WOLF", "SPONGE", "PAPER", "MOON", "AIR", "BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE");
        addSymbolWithDefeats("MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON", "AIR", "BOWL", "WATER", "ALIEN");
        addSymbolWithDefeats("SUN", "FIRE", "SCISSORS", "AXE", "SNAKE", "MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER");
        addSymbolWithDefeats("DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK", "SUN", "FIRE", "SCISSORS", "AXE", "SNAKE", "MONKEY", "WOMAN");
        addSymbolWithDefeats("AIR", "BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE", "DYNAMITE", "GUN", "ROCK", "SUN", "FIRE");
        addSymbolWithDefeats("COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON", "AIR", "BOWL", "WATER", "ALIEN", "DRAGON", "DEVIL", "LIGHTNING", "NUKE");
        addSymbolWithDefeats("SNAKE", "MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON", "AIR", "BOWL", "WATER");
        addSymbolWithDefeats("ROCK", "SUN", "FIRE", "SCISSORS", "AXE", "SNAKE", "MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH", "WOLF", "SPONGE");
        addSymbolWithDefeats("FIRE", "SCISSORS", "AXE", "SNAKE", "MONKEY", "WOMAN", "MAN", "TREE", "COCKROACH", "WOLF", "SPONGE", "PAPER", "MOON");
    }

    // Helper method to create a symbol and its defeat relationships
    private void addSymbolWithDefeats(String symbolName, String... defeatedSymbols) {
        Symbol symbol = new Symbol(symbolName);
        for (String defeat : defeatedSymbols) {
            symbol.addDefeat(defeat);
        }
        symbols.put(symbolName, symbol);
    }

    // Determine the winner between two symbols
    public String determineWinner(String symbol1Name, String symbol2Name) {
        Symbol symbol1 = symbols.get(symbol1Name);
        Symbol symbol2 = symbols.get(symbol2Name);

        if (symbol1.defeats(symbol2)) {
            return symbol1Name + " wins!";
        } else if (symbol2.defeats(symbol1)) {
            return symbol2Name + " wins!";
        } else {
            return "It's a tie!";
        }
    }
}
