package classobject.rps25game;
import java.util.HashSet;
import java.util.Set;

public class Symbol {
   private String name;
    private Set<String> defeats;

    public Symbol(String name) {
        this.name = name;
        this.defeats = new HashSet<>();
    }

    // Add a symbol to the set of symbols this symbol can defeat
    public void addDefeat(String symbolName) {
        defeats.add(symbolName);
    }

    // Check if this symbol defeats another symbol
    public boolean defeats(Symbol other) {
        return defeats.contains(other.name);
    }

    public String getName() {
        return name;
    } 
}
